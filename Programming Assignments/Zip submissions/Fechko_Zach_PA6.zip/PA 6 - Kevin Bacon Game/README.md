# PA 6 - Kevin Bacon Game

## Assignment Instructions

## Assignment Notes
Ways to keep track of kevin bacon numbers/path length:
- Create a dictionary on game start and with each actor that is searched for, add a key value pair of actor name and kb number