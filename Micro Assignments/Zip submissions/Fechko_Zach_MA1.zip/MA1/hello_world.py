"""
 this is the same file that I created in the terminal, if I was supposed to make another hello_world.py please let me know 
 My IDE of choice is Visual Studio Code because I already had it installed, if I am required to use a different IDE, please let me know
"""

print("Hello World")